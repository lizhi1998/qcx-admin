'use strict'
module.exports = {
  NODE_ENV: '"production"',//生产环境
  API_HOST: '"https://qcxapi.fjut.edu.cn"'
}
