module.exports = {
　　publicPath:"/admin"
}