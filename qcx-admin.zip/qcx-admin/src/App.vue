<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<script type="text/javascript">
export default {};
</script>
<style src="@/assets/css/base.css"></style>
